import { foregroundFetch } from './components/app-loading';
import { notifySessionFailure } from './session-client';

export type AccessScope = 'GLOBAL' | 'BRANCH';
export type OverrideEffect = 'GRANT' | 'DENY';

export interface CapabilityDefinition {
  key: string;
  label: string;
  description: string;
  category: string;
  sensitive: boolean;
  active: boolean;
  systemOnly: boolean;
  globalOnly: boolean;
}

export interface AccessRole {
  id: string;
  code: string;
  displayName: string;
  description: string;
  scope: AccessScope;
  systemRole: string | null;
  system: boolean;
  protected: boolean;
  active: boolean;
  version: number;
  affectedUsers: number;
  capabilities: Array<
    Pick<
      CapabilityDefinition,
      'key' | 'label' | 'category' | 'sensitive' | 'systemOnly' | 'globalOnly'
    >
  >;
  createdAt: string;
  updatedAt: string;
}

export interface UserAccess {
  user: {
    id: string;
    displayName: string;
    status: 'PENDING_ACTIVATION' | 'ACTIVE' | 'INACTIVE';
    version: number;
  };
  roleAssignments: Array<{
    id: string;
    roleId: string | null;
    roleCode: string;
    displayName: string;
    scope: AccessScope;
    branchId: string | null;
    branch: { id: string; code: string; name: string } | null;
    source: 'DIRECT' | 'ASSIGNMENT';
  }>;
  overrides: Array<{
    id: string;
    capabilityKey: string;
    capabilityLabel: string;
    effect: OverrideEffect;
    branchId: string | null;
    branch: { id: string; code: string; name: string } | null;
    reasonCode: string;
    version: number;
    createdAt: string;
  }>;
  effective: {
    capabilities: string[];
    branches: string[];
    grants: Array<{
      capability: string;
      branchId: string | null;
      source: 'SYSTEM_ROLE' | 'CUSTOM_ROLE' | 'USER_OVERRIDE';
      sourceId: string;
    }>;
    denials: Array<{ capability: string; branchId: string | null; sourceId: string }>;
  };
}

export interface AccessMutationReason {
  reasonCode: string;
  note?: string;
}

export interface AccessClient {
  listCapabilities(filters?: {
    q?: string;
    category?: string;
    sensitive?: boolean;
    active?: boolean;
  }): Promise<CapabilityDefinition[]>;
  listRoles(filters?: { q?: string; scope?: AccessScope; active?: boolean }): Promise<AccessRole[]>;
  createRole(
    input: {
      code: string;
      displayName: string;
      description: string;
      scope: AccessScope;
      capabilityKeys: string[];
    } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<AccessRole>;
  updateRole(
    id: string,
    input: {
      displayName: string;
      description: string;
      expectedVersion: number;
    } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<AccessRole>;
  replaceRoleCapabilities(
    id: string,
    input: { capabilityKeys: string[]; expectedVersion: number } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<AccessRole>;
  deactivateRole(
    id: string,
    input: { expectedVersion: number } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<void>;
  getUserAccess(userId: string): Promise<UserAccess>;
  replaceUserRoles(
    userId: string,
    input: {
      roles: Array<{ roleId: string; branchId?: string | null }>;
      expectedVersion: number;
    } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<void>;
  createOverride(
    userId: string,
    input: {
      capabilityKey: string;
      branchId?: string | null;
      effect: OverrideEffect;
    } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<void>;
  revokeOverride(
    userId: string,
    overrideId: string,
    input: { expectedVersion: number } & AccessMutationReason,
    idempotencyKey: string,
  ): Promise<void>;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await foregroundFetch(
    `/api/v1${path}`,
    {
      ...init,
      credentials: 'include',
      headers: {
        'content-type': 'application/json',
        ...init.headers,
      },
    },
    init.method && init.method !== 'GET' ? 'Menyimpan pengaturan akses…' : 'Memuat akses…',
  );
  if (!response.ok) {
    const problem = await response.json().catch(() => undefined);
    const error = { response: { status: response.status, data: problem } };
    notifySessionFailure(error);
    throw error;
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

function query(filters: Record<string, string | boolean | undefined>) {
  const values = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== '') values.set(key, String(value));
  });
  const serialized = values.toString();
  return serialized ? `?${serialized}` : '';
}

function mutation<T>(path: string, method: 'POST' | 'PUT' | 'PATCH', body: unknown, key: string) {
  return request<T>(path, {
    method,
    headers: { 'idempotency-key': key },
    body: JSON.stringify(body),
  });
}

export const browserAccessClient: AccessClient = {
  async listCapabilities(filters = {}) {
    return (
      await request<{ items: CapabilityDefinition[] }>(`/access/capabilities${query(filters)}`)
    ).items;
  },
  async listRoles(filters = {}) {
    return (await request<{ items: AccessRole[] }>(`/access/roles${query(filters)}`)).items;
  },
  createRole(input, key) {
    return mutation('/access/roles', 'POST', input, key);
  },
  updateRole(id, input, key) {
    return mutation(`/access/roles/${id}`, 'PATCH', input, key);
  },
  replaceRoleCapabilities(id, input, key) {
    return mutation(`/access/roles/${id}/capabilities`, 'PUT', input, key);
  },
  deactivateRole(id, input, key) {
    return mutation(`/access/roles/${id}/deactivate`, 'POST', input, key);
  },
  getUserAccess(userId) {
    return request(`/users/${userId}/access`);
  },
  replaceUserRoles(userId, input, key) {
    return mutation(`/users/${userId}/access/roles`, 'PUT', input, key);
  },
  createOverride(userId, input, key) {
    return mutation(`/users/${userId}/permission-overrides`, 'POST', input, key);
  },
  revokeOverride(userId, overrideId, input, key) {
    return mutation(
      `/users/${userId}/permission-overrides/${overrideId}/revoke`,
      'POST',
      input,
      key,
    );
  },
};

export function accessFailureCode(error: unknown): string {
  const response = (
    error as {
      response?: {
        status?: number;
        data?: { error?: { code?: string }; code?: string };
      };
    }
  ).response;
  return (
    response?.data?.error?.code ??
    response?.data?.code ??
    (response?.status === 403 ? 'FORBIDDEN' : 'REQUEST_FAILED')
  );
}
