import { mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import {
  createNativeIntegrationDatabase,
  databaseNameForRun,
  dropNativeIntegrationDatabase,
  validateRunId,
} from './native-mysql-harness.mjs';

const root = resolve(import.meta.dirname, '..');
const evidenceRoot = resolve(root, '.integration-evidence');
const args = process.argv.slice(2);
const cleanupMode = args[0] === 'cleanup';
const keep = args.includes('--keep');
const runIdArgument = args.findIndex((value) => value === '--run-id');
const requestedRunId = runIdArgument >= 0 ? args[runIdArgument + 1] : undefined;
const runId = validateRunId(
  requestedRunId ??
    `api_${new Date().toISOString().replace(/\D/gu, '').slice(0, 14)}_${process.pid}`,
);

function run(command, commandArgs, options = {}) {
  return new Promise((resolveResult, rejectResult) => {
    const child = spawn(command, commandArgs, {
      cwd: root,
      env: { ...process.env, ...options.env },
      stdio: 'inherit',
    });
    child.once('error', rejectResult);
    child.once('exit', (code, signal) => resolveResult({ code: code ?? 1, signal }));
  });
}

if (cleanupMode) {
  if (!requestedRunId) throw new Error('RUN_ID_REQUIRED');
  await dropNativeIntegrationDatabase(runId);
  process.exit(0);
}

const evidenceDirectory = resolve(evidenceRoot, runId);
await mkdir(evidenceDirectory, { recursive: true });
const startedAt = new Date().toISOString();
let status = 'FAILED';
let testExitCode = 1;
let mysqlInfo;
let databaseCreated = false;

try {
  mysqlInfo = await createNativeIntegrationDatabase(runId);
  databaseCreated = true;
  const environment = {
    DATABASE_URL: mysqlInfo.databaseUrl,
    NODE_ENV: 'test',
    REDIS_URL: '',
    PRIVATE_UPLOAD_ROOT: resolve(evidenceDirectory, 'private'),
    PAYMENT_PROOF_SCAN_DRIVER: 'synthetic',
    PAYMENT_PROOF_SYNTHETIC_SCAN_RESULT: 'CLEAN',
  };
  await mkdir(environment.PRIVATE_UPLOAD_ROOT, { recursive: true });
  const migrated = await run(
    'pnpm',
    [
      '--dir',
      'apps/api',
      'exec',
      'prisma',
      'migrate',
      'deploy',
      '--schema',
      'prisma/schema.prisma',
    ],
    { env: environment },
  );
  if (migrated.code !== 0) throw new Error('INTEGRATION_PRISMA_MIGRATION_FAILED');
  const tested = await run(
    'pnpm',
    [
      '--dir',
      'apps/api',
      'exec',
      'jest',
      '--runInBand',
      '--testPathPatterns=integration\\.spec\\.ts$',
    ],
    { env: environment },
  );
  testExitCode = tested.code;
  if (tested.code !== 0) throw new Error('INTEGRATION_TESTS_FAILED');
  status = 'PASSED';
} finally {
  const evidence = {
    runId,
    status,
    startedAt,
    completedAt: new Date().toISOString(),
    mysql: {
      version: mysqlInfo?.version ?? 'unavailable',
      host: mysqlInfo?.host ?? 'local',
      port: mysqlInfo?.port ?? null,
      database: mysqlInfo?.database ?? databaseNameForRun(runId),
      execution: 'native',
    },
    redisConfigured: false,
    testExitCode,
  };
  await writeFile(
    resolve(evidenceDirectory, 'evidence.json'),
    `${JSON.stringify(evidence, null, 2)}\n`,
  );
  if (databaseCreated && !keep) await dropNativeIntegrationDatabase(runId);
  else if (databaseCreated)
    process.stderr.write(`[api-integration] database retained for run ${runId}\n`);
}

if (status !== 'PASSED') process.exit(1);
