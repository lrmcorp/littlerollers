import { createServer } from 'node:net';
import { mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import {
  createNativeIntegrationDatabase,
  databaseNameForRun,
  dropNativeIntegrationDatabase,
  validateRunId,
} from './native-mysql-harness.mjs';

const root = resolve(import.meta.dirname, '..');
const evidenceRoot = resolve(root, '.integration-evidence');
const args = process.argv.slice(2);
const cleanupMode = args[0] === 'cleanup';
const keep = args.includes('--keep');
const runIdArgument = args.findIndex((value) => value === '--run-id');
const requestedRunId = runIdArgument >= 0 ? args[runIdArgument + 1] : undefined;
const runId = validateRunId(
  requestedRunId ??
    `customer_${new Date().toISOString().replace(/\D/gu, '').slice(0, 14)}_${process.pid}`,
);

function run(command, commandArgs, options = {}) {
  return new Promise((resolveResult, rejectResult) => {
    const child = spawn(command, commandArgs, {
      cwd: root,
      env: { ...process.env, ...options.env },
      stdio: 'inherit',
    });
    child.once('error', rejectResult);
    child.once('exit', (code, signal) => resolveResult({ code: code ?? 1, signal }));
  });
}

async function reservePort() {
  const server = createServer();
  await new Promise((resolveReady, rejectReady) => {
    server.once('error', rejectReady);
    server.listen(0, '127.0.0.1', resolveReady);
  });
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('CUSTOMER_E2E_PORT_UNAVAILABLE');
  await new Promise((resolveClose) => server.close(resolveClose));
  return address.port;
}

if (cleanupMode) {
  if (!requestedRunId) throw new Error('RUN_ID_REQUIRED');
  await dropNativeIntegrationDatabase(runId);
  process.exit(0);
}

const [apiPort, webPort] = await Promise.all([reservePort(), reservePort()]);
const evidenceDirectory = resolve(evidenceRoot, runId);
const privateRoot = resolve(evidenceDirectory, 'private');
await mkdir(privateRoot, { recursive: true });
let mysqlInfo;
let databaseCreated = false;
let status = 'FAILED';
let exitCode = 1;
const startedAt = new Date().toISOString();

try {
  mysqlInfo = await createNativeIntegrationDatabase(runId);
  databaseCreated = true;
  const environment = {
    DATABASE_URL: mysqlInfo.databaseUrl,
    NODE_ENV: 'test',
    REDIS_URL: '',
    PRIVATE_UPLOAD_ROOT: privateRoot,
    PAYMENT_PROOF_SCAN_DRIVER: 'synthetic',
    PAYMENT_PROOF_SYNTHETIC_SCAN_RESULT: 'CLEAN',
    DD_CUSTOMER_E2E_SKIP_WORKER: 'true',
    DD_CUSTOMER_E2E_RUN_ID: runId,
    DD_CUSTOMER_E2E_API_PORT: String(apiPort),
    DD_PLAYWRIGHT_PORT: String(webPort),
  };
  const migrated = await run(
    'pnpm',
    [
      '--dir',
      'apps/api',
      'exec',
      'prisma',
      'migrate',
      'deploy',
      '--schema',
      'prisma/schema.prisma',
    ],
    { env: environment },
  );
  if (migrated.code !== 0) throw new Error('CUSTOMER_E2E_MIGRATION_FAILED');
  const seeded = await run(
    'node',
    ['--import', './apps/api/node_modules/tsx/dist/loader.mjs', 'apps/api/prisma/seed.ts'],
    { env: { ...environment, SEED_PROFILE: 'demo' } },
  );
  if (seeded.code !== 0) throw new Error('CUSTOMER_E2E_SEED_FAILED');
  const tested = await run('node', ['tools/run-customer-e2e.mjs'], { env: environment });
  exitCode = tested.code;
  if (tested.code !== 0) throw new Error('CUSTOMER_E2E_FAILED');
  status = 'PASSED';
} finally {
  await writeFile(
    resolve(evidenceDirectory, 'customer-e2e.json'),
    `${JSON.stringify(
      {
        runId,
        status,
        startedAt,
        completedAt: new Date().toISOString(),
        mysql: {
          version: mysqlInfo?.version ?? 'unavailable',
          host: mysqlInfo?.host ?? 'local',
          port: mysqlInfo?.port ?? null,
          database: mysqlInfo?.database ?? databaseNameForRun(runId),
          execution: 'native',
        },
        apiPort,
        webPort,
        redisConfigured: false,
        workerStarted: false,
        exitCode,
      },
      null,
      2,
    )}\n`,
  );
  if (databaseCreated && !keep) await dropNativeIntegrationDatabase(runId);
  else if (databaseCreated)
    process.stderr.write(`[customer-e2e] database retained for run ${runId}\n`);
}

if (status !== 'PASSED') process.exit(1);
